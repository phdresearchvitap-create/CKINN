# Objective 1 · AUDIT

Reanalysis. Results below are read from this run's saved tables.

Software and data checks only. These outputs support no study performance conclusion.

## A

The paired comparison has not run.

The binary-zero screening subset has unresolved producer recoding for borderline and missing responses. Interpret it at the extract level.

## B_as_coded

The paired comparison has not run.

Five- and seven-year hypotheses are inactive. Study claims require a scientific-profile run and review of support, calibration, missingness and fit failures.