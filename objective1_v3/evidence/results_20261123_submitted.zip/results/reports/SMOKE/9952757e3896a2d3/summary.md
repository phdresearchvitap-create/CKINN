# Objective 1 · SMOKE

Reanalysis. Results below are read from this run's saved tables.

Software and data checks only. These outputs support no study performance conclusion.

## A

M3 minus M1 Brier difference 0. The paired 95% interval [0, 0] includes zero. Negative values favor M3. Uncertainty is conditional on these fitted models.

M1 had Brier 0.16045, AUROC 0.1968, average precision 0.004867, mean prediction 0.3983, and adjusted observed fraction 0.00774. Calibration intercept -4.441 and slope -11.85 use 6000 participants with 39 known cases.

M3 had Brier 0.16045, AUROC 0.1968, average precision 0.004867, mean prediction 0.3983, and adjusted observed fraction 0.00774. Calibration intercept -4.441 and slope -11.85 use 6000 participants with 39 known cases.

Analytical versus numerical direction checks recorded 0 disagreements outside tolerance. See eligible denominators and flatness in directions.csv.

120 of 140 model-by-group estimates lacked the prespecified support.

The binary-zero screening subset has unresolved producer recoding for borderline and missing responses. Interpret it at the extract level.

## B_as_coded

M3 minus M1 Brier difference 0. The paired 95% interval [0, 0] includes zero. Negative values favor M3. Uncertainty is conditional on these fitted models.

M1 had Brier 0.11846, AUROC 0.6823, average precision 0.05318, mean prediction 0.3295, and adjusted observed fraction 0.02989. Calibration intercept -2.771 and slope 8.856 use 4851 participants with 145 known cases.

M3 had Brier 0.11846, AUROC 0.6823, average precision 0.05318, mean prediction 0.3295, and adjusted observed fraction 0.02989. Calibration intercept -2.771 and slope 8.856 use 4851 participants with 145 known cases.

Analytical versus numerical direction checks recorded 0 disagreements outside tolerance. See eligible denominators and flatness in directions.csv.

2 of 12 model-by-group estimates lacked the prespecified support.

Five- and seven-year hypotheses are inactive. Study claims require a scientific-profile run and review of support, calibration, missingness and fit failures.